#ifndef __LAB6_PART2_H_
#define __LAB6_PART2_H_

#include "io.h"
#include <stdio.h>
#include "system.h"
#include "alt_types.h"

// create standard embedded type definitions
typedef   signed char   sint8;              // signed 8 bit values
typedef unsigned char   uint8;              // unsigned 8 bit values
typedef   signed short  sint16;             // signed 16 bit values
typedef unsigned short  uint16;             // unsigned 16 bit values
typedef   signed long   sint32;             // signed 32 bit values
typedef unsigned long   uint32;             // unsigned 32 bit values
typedef         float   real32;             // 32 bit real values

uint8* LedPtr      = (uint8*)LEDS_BASE;
uint32* StartAddress = (uint32*)INFERRED_RAM_BASE;

void test_RAM_byte_access(uint8* start_address, int num_bytes, uint8 data);
void test_RAM_2byte_access(uint16* start_address, int num_halfwords, uint16 data);
void test_RAM_4byte_access(uint32* start_address, int num_words, uint32 data);

#endif /*__LAB6_PART2_H_*/
