#include "Lab6_Part2.h"

int main()
{
	uint32 test_data = 0x12345678;
	while(1)
	{
		test_RAM_4byte_access(StartAddress, 4096, test_data);
	}
	return 0;
}


void test_RAM_byte_access(uint8* start_address, int num_bytes, uint8 data)
{
	uint8* byte_ptr = start_address;
	uint8 byte_data = *start_address;
	for(int i = 0; i < num_bytes; i++)
	{
		*(byte_ptr + i) = data; //write data to start address
	}
	for(int i = 0; i < num_bytes; i++)
	{
		byte_data = *(byte_ptr + 1);
		if(byte_data != data)
		{
			*LedPtr = 0xFF;
		}
	}

}

void test_RAM_2byte_access(uint16* start_address, int num_halfwords, uint16 data)
{
	uint16* hw_ptr = start_address;
	uint16 hw_data = *start_address;
	for(int i = 0; i < num_halfwords; i++)
	{
		*(hw_ptr + i) = data; //write data to start address
	}
	for(int i = 0; i < num_halfwords; i++)
	{
		hw_data = *(hw_ptr + 1); //read data from start address
		if(hw_data != data)//verify data
		{
			*LedPtr = 0xFF;
		}
	}
}

void test_RAM_4byte_access(uint32* start_address, int num_words, uint32 data)
{
	uint32* w_ptr = start_address;
	uint32 w_data = *start_address;
	for(int i = 0; i < num_words; i++)
	{
		*(w_ptr + i) = data; //write data to start address
	}
	for(int i = 0; i < num_words; i++)
	{
		w_data = *(w_ptr + i);
		if(w_data != data)
		{
			*LedPtr = 0xFF;
		}
		else
		{
			*LedPtr = 0;
		}
	}
}
