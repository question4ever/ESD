#include "Lab7_Part5.h"

void pushbutton_isr(void *context)
{
	printf("RAM TEST DONE");
	*LedPtr = 0xAA;
	*(KeyPtr + 12) = 1;
}

int main()
{
	*(KeyPtr + 8) |= 0x01; //enable interrupts on the GPIO port
	alt_ic_isr_register(PUSHBUTTONS_IRQ_INTERRUPT_CONTROLLER_ID,PUSHBUTTONS_IRQ,pushbutton_isr,0,0); //register and enable global interrupts

	uint8 test_data = 0x00;
	uint16 test_hw_data = 0x1234;
	uint32 test_w_data = 0xABCDEF90;

	while(1)
	{
		test_RAM_byte_access((uint8 *)StartAddress, 16384, test_data);
		*LedPtr = 0;
		test_RAM_2byte_access((uint16*)StartAddress, 8192, test_hw_data);
		*LedPtr = 0;
		test_RAM_4byte_access((uint32*)StartAddress, 4096, test_w_data);
		*LedPtr = 0;
		test_RAM_4byte_access((uint32*)StartAddress, 4096, 0x12345678);
		*LedPtr = 0;
	}
	return 0;
}


void test_RAM_byte_access(uint8* start_address, int num_bytes, uint8 data)
{
	uint8* byte_ptr = start_address;
	uint8 byte_data = *start_address;
	for(int i = 0; i < num_bytes; i++)
	{
		*(byte_ptr + i) = data; //write data to start address
	}
	for(int i = 0; i < num_bytes; i++)
	{
		byte_data = *(byte_ptr + i);
		if(byte_data != data)
		{
			printf("ERROR: Address: 0x%08x Read: 0x%08x Expected: 0x%08x \n\r", (byte_ptr + i), byte_data, data);
			*LedPtr = 0xFF;
		}
		else
		{
			*LedPtr = 0;
		}
	}

}

void test_RAM_2byte_access(uint16* start_address, int num_halfwords, uint16 data)
{
	uint16* hw_ptr = start_address;
	uint16 hw_data = *start_address;
	for(int i = 0; i < num_halfwords; i++)
	{
		*(hw_ptr + i) = data; //write data to start address
	}
	for(int i = 0; i < num_halfwords; i++)
	{
		hw_data = *(hw_ptr + i); //read data from start address
		if(hw_data != data)//verify data
		{
			printf("ERROR: Address: 0x%08x Read: 0x%08x Expected: 0x%08x \n\r", (hw_ptr + i), hw_data, data);
			*LedPtr = 0xFF;
		}
		else
		{
			*LedPtr = 0;
		}
	}
}

void test_RAM_4byte_access(uint32* start_address, int num_words, uint32 data)
{
	uint32* w_ptr = start_address;
	uint32 w_data = *start_address;
	for(int i = 0; i < num_words; i++)
	{
		*(w_ptr + i) = data; //write data to start address
	}
	for(int i = 0; i < num_words; i++)
	{
		w_data = *(w_ptr + i);
		if(w_data != data)
		{
			printf("ERROR: Address: 0x%08x Read: 0x%08x Expected: 0x%08x \n\r", (w_ptr + i), w_data, data);
			*LedPtr = 0xFF;
		}
		else
		{
			*LedPtr = 0;
		}
	}
}
