/* This is a C program written for the timer interrupt demo.  The
 program assumes a nios_system with a periodic interrupt timer
 and an 8-bit output PIO named leds. */


/* alt_types.h and sys/alt_irq.h need to be included for the interrupt
  functions
  system.h is necessary for the system constants
  io.h has read and write functions */
#include "io.h"
#include <stdio.h>
#include "system.h"
#include "alt_types.h"
#include "sys/alt_irq.h"
#include "altera_avalon_timer_regs.h"
#include "altera_avalon_timer.h"

// create standard embedded type definitions
typedef   signed char   sint8;              // signed 8 bit values
typedef unsigned char   uint8;              // unsigned 8 bit values
typedef   signed short  sint16;             // signed 16 bit values
typedef unsigned short  uint16;             // unsigned 16 bit values
typedef   signed long   sint32;             // signed 32 bit values
typedef unsigned long   uint32;             // unsigned 32 bit values
typedef         float   real32;             // 32 bit real values

uint32* TimerPtr    = (uint32*)TIMER_0_BASE;
uint8* LedPtr      = (uint8*)LEDS_BASE;
uint8* SwitchPtr = (uint8*)SWITCHES_BASE;
uint8* KeyPtr	= (uint8*)PUSHBUTTONS_BASE;
uint8* Hex0Ptr = (uint8*)HEX0_BASE;

const uint8 KEY_DOWN_1 = 13;
const uint8 KEY_UP_1 = 15;
const uint8 SWITCH_1 = 0x01;

const uint8 HEXCONSTANTS[16] = {0x40,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x98,0x88,0x83,0xC6,0xA1,0x86,0x8E};

volatile int global_count = 0;

void pushbutton_isr(void *context)
{
	uint8 sw_1 = *SwitchPtr & SWITCH_1;
	if(sw_1 == SWITCH_1)
	{
		if(global_count == 15)
		{
			global_count = 0;
		}
		else
		{
			global_count++;
		}
	}
	else
	{
		if(global_count == 0)
		{
			global_count = 15;
		}
		else
		{
			global_count--;
		}
	}
	*(KeyPtr + 12) = 1;
}

void timer_isr(void *context)
{
	//clear timer interrupt
	*TimerPtr = 0;
	*LedPtr ^= 0xFF; //toggle LEDs

}

int main()
{
	*(KeyPtr + 8) |= 0x02; //enable interrupts on the GPIO port
	alt_ic_isr_register(PUSHBUTTONS_IRQ_INTERRUPT_CONTROLLER_ID,PUSHBUTTONS_IRQ,pushbutton_isr,0,0); //register and enable global interrupts
	alt_ic_isr_register(TIMER_0_IRQ_INTERRUPT_CONTROLLER_ID,TIMER_0_IRQ,timer_isr,0,0);
	while(1)
	{
		*Hex0Ptr = HEXCONSTANTS[global_count];
	}
	return 0;
}
