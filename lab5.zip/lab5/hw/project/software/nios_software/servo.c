#include "servo.h"

uint32* locked_min_angle_count;
uint32* locked_max_angle_count;

int main()
{
	*(KeyPtr + 8) |= 0x0C; //enable interrupts for pushbuttons 2 and 3
	alt_ic_isr_register(PUSHBUTTONS_IRQ_INTERRUPT_CONTROLLER_ID,PUSHBUTTONS_IRQ,pushbutton_isr,0,0); //register and enable global interrupts
	alt_ic_isr_register(SERVO_CONTROLLER_0_IRQ_INTERRUPT_CONTROLLER_ID,SERVO_CONTROLLER_0_IRQ,servo_controller_isr,0,0);
	uint32 min_angle_count, max_angle_count;

	min_angle_count = calculate_angle_count(45);
	max_angle_count = calculate_angle_count(135);

	locked_min_angle_count = &min_angle_count;
	locked_max_angle_count = &max_angle_count;

	while(1)
	{
		uint8 min_angle_dec, max_angle_dec;
		min_angle_dec = calculate_angle(*locked_min_angle_count);
		max_angle_dec = calculate_angle(*locked_max_angle_count);
		display_min_and_max_angles(min_angle_dec, max_angle_dec);
	}
	return 0;
}

void display_min_and_max_angles(uint8 min_angle, uint8 max_angle)
{
	uint8 min_angle_tens_pos = min_angle / 10;
	uint8 min_angle_ones_pos = min_angle % 10;
	
	uint8 max_angle_hundreds_pos = (max_angle / 100);
	uint8 max_angle_tens_pos = (max_angle % 100) / 10;
	uint8 max_angle_ones_pos = (max_angle % 100) % 10;
	
	*min_angle_hex_display = HEXCONSTANTS[min_angle_tens_pos] << 8 | HEXCONSTANTS[min_angle_ones_pos];
	*max_angle_hex_display = 0xFF << 24 | HEXCONSTANTS[max_angle_hundreds_pos] << 16 | HEXCONSTANTS[max_angle_tens_pos] << 8
			| HEXCONSTANTS[max_angle_ones_pos];
}

uint32 calculate_angle_count(uint8 angle)
{
	uint32 angle_count = ((5000*angle)/9) + 25000;
	return angle_count;
}

uint8 calculate_angle(uint32 angle_count)
{
	uint8 angle = ((9*angle_count)/5000) - 45;
	return angle;
}

void pushbutton_isr()
{
	uint32 edge_capture_reg = *(KeyPtr + 12);
	uint8 switches_val = *SwitchPtr;
	if(switches_val >= 45 && switches_val <= 135){
		if((edge_capture_reg & KEY3) == KEY3)
		{
			*locked_min_angle_count = calculate_angle_count(switches_val);
		}
		else if((edge_capture_reg & KEY2) == KEY2)
		{
			*locked_max_angle_count = calculate_angle_count(switches_val);
		}
	}
	*(KeyPtr + 12) = 1;
}

void servo_controller_isr()
{
	uint32 min_angle = *locked_min_angle_count;
	uint32 max_angle = *locked_max_angle_count;
	*sc_min_angle_count = min_angle;
	*sc_max_angle_count = max_angle;
}

