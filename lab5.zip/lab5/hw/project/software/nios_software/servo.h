/*
 * servo.h
 *
 *  Created on: Mar 19, 2019
 *      Author: sra2270
 */

#ifndef SERVO_H_
#define SERVO_H_

#include "io.h"
#include <stdio.h>
#include "system.h"
#include "alt_types.h"
#include "sys/alt_irq.h"

// create standard embedded type definitions
typedef   signed char   sint8;              // signed 8 bit values
typedef unsigned char   uint8;              // unsigned 8 bit values
typedef   signed short  sint16;             // signed 16 bit values
typedef unsigned short  uint16;             // unsigned 16 bit values
typedef   signed long   sint32;             // signed 32 bit values
typedef unsigned long   uint32;             // unsigned 32 bit values
typedef         float   real32;             // 32 bit real values

#define KEY2 0x04
#define KEY3 0x08

uint8* SwitchPtr = (uint8*)SWITCHES_BASE;
uint16* min_angle_hex_display	= (uint16*)HEX5_4_BASE;
uint32* max_angle_hex_display	= (uint32*)HEX3_0_BASE;
uint8* KeyPtr	= (uint8*)PUSHBUTTONS_BASE;
uint32* sc_min_angle_count = (uint32*)SERVO_CONTROLLER_0_BASE;
uint32* sc_max_angle_count = ((uint32*)SERVO_CONTROLLER_0_BASE + 1);

const uint8 HEXCONSTANTS[16] = {0x40,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x98,0x88,0x83,0xC6,0xA1,0x86,0x8E};

void display_min_and_max_angles(uint8 min_angle, uint8 max_angle);
uint32 calculate_angle_count(uint8 angle);
uint8 calculate_angle(uint32 angle_count);
void pushbutton_isr();
void servo_controller_isr();
#endif /* SERVO_H_ */
